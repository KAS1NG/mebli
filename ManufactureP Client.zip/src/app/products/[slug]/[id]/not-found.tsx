export default function NotFound() {
    return <h1 className="productLoading">Product Not Found</h1>;
  }
  