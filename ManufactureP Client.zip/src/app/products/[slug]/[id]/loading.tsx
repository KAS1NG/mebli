import '@/app/styles/productDetail.scss';

export default function Loading() {
  return <p className="productLoading">Завантажуємо вміст товару...</p>;
}
