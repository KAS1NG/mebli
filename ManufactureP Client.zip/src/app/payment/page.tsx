import React from 'react'
import ProceedToCheckout from '../components/ProceedToCheckout'

function page() {
  return (
    <ProceedToCheckout />
  )
}

export default page